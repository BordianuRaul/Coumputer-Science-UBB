#include "FilePlayList.h"

FilePlayList::FilePlayList(std::string filename) 
	: filename {filename}
{}
