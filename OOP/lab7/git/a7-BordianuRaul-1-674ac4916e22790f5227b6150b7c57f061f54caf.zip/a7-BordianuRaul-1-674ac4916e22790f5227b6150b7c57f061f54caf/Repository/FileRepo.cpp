//
// Created by Raul on 5/1/2023.
//

#include "FileRepo.h"

#include <utility>
#include <fstream>
#include <iostream>
#include <exception>
#include <sstream>

using namespace std;

FileRepo::FileRepo() {

    this->filename = "basic.txt";

}

FileRepo::FileRepo(std::string filename)
{
    this->filename = filename;
    this->loadFromFile();
}

std::string FileRepo::createStringTutorial(const Tutorial& tutorial) {

    std::string stringTutorial;

    stringTutorial = stringTutorial + tutorial.getId() + ",";
    stringTutorial = stringTutorial + tutorial.getTitle() + ",";
    stringTutorial = stringTutorial + tutorial.getPresenter() + ",";
    stringTutorial = stringTutorial + tutorial.getDuration() + ",";
    stringTutorial = stringTutorial + std::to_string(tutorial.getNrLikes()) + ",";
    stringTutorial = stringTutorial + tutorial.getLink() + "\n";

    return stringTutorial;
}

void FileRepo::addElem(Tutorial tutorial) {

    Repository<Tutorial>::addElem(tutorial);

    this->writeToFile();
}

void FileRepo::writeToFile() {

    std::string path = "../" + this->filename;
    std::ofstream fileOut(path);

    if (!fileOut.is_open())
        throw std::exception();

    for(const auto& tutorial : this->elements) {
        std::string stringTutorial = this->createStringTutorial(tutorial);

        if (fileOut.is_open()) {
            fileOut << stringTutorial;

        }
    }

    fileOut.close();

}

void FileRepo::loadFromFile()
{
    std::string path = "../" + this->filename;
    if(!path.empty()) {
        std::ifstream file(path);

        if(!file.good())
        {
            std::ofstream file(path);
            file.close();

            // reopen the file for input
            file.open(path);
        }

        if(!file.is_open())
            throw std::runtime_error("Failed to open file.");

        std::string line;
        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string id, title, presenter, duration, nrLikesStr, link;

            std::getline(ss, id, ',');
            std::getline(ss, title, ',');
            std::getline(ss, presenter, ',');
            std::getline(ss, duration, ',');
            std::getline(ss, nrLikesStr, ',');
            std::getline(ss, link, '\n');

            int nrLikes = std::stoi(nrLikesStr);
            Tutorial tutorial(id, title, presenter, duration, nrLikes, link);

            this->elements.push_back(tutorial);
        }

        file.close();
    }
}

void FileRepo::clearFile() {
    std::string path = "../" + this->filename;
    std::ofstream fileOut(path, std::ios::trunc);  // truncating file deletes its content

    if (!fileOut.is_open())
        throw std::runtime_error("Failed to open file.");

    fileOut.close();
}

void FileRepo::deleteRepo(Tutorial tutorial) {

    Repository<Tutorial>::deleteRepo(tutorial);

    this->writeToFile();

}

FileRepo& FileRepo::operator=(const FileRepo &rhs) {

    if(this != &rhs){
        this->elements =rhs.elements;
        this->filename = rhs.filename;
    }
    return *this;
}
