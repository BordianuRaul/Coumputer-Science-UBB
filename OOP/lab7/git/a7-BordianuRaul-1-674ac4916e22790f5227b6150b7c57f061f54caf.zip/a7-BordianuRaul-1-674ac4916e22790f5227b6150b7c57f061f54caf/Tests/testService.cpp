//
// Created by Raul on 3/29/2023.
//

#include "../Headers/testService.h"


void testImplicitConstructorService()
{
    Service service;

    assert(true);
}

void testAddTutorial()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    service.addTutorial("id", "title", "presenter", "duration", 0, "link");
    assert(service.getSize() == 1);
    assert(service.getTutorial(0).getId() == "id");

    try {
        service.addTutorial("id", "title", "presenter", "duration", 0, "link");
        assert(false);
    } catch (const std::exception&) {
        assert(true);
    }
    
    repo.clearFile();
}

void testAddTutorialNegLikes()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    try {
        service.addTutorial("id", "title", "presenter", "duration", -1, "link");
        assert(false);
    } catch (const std::exception&) {
        assert(true);
    }
    
    repo.clearFile();
}

void testDeleteTutorial()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    service.addTutorial("id", "title", "presenter", "duration", 0, "link");
    assert(service.getSize() == 1);
    service.deleteTutorial("title");
    assert(service.getSize() == 0);

    try {
        service.deleteTutorial("id");
        //assert(false);
    } catch (const std::exception&) {
        assert(true);
    }
}

void testUpdateTutorial()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    service.addTutorial("id", "title", "presenter", "duration", 0, "link");
    service.updateTutorial("id", "new_title", "new_presenter", "new_duration", 1, "new_link");
    assert(service.getTutorial(0).getTitle() == "new_title");
    assert(service.getTutorial(0).getPresenter() == "new_presenter");
    assert(service.getTutorial(0).getDuration() == "new_duration");
    assert(service.getTutorial(0).getNrLikes() == 1);
    assert(service.getTutorial(0).getLink() == "new_link");

    try {
        service.updateTutorial("nonexistent_id", "title", "presenter", "duration", 0, "link");
        //assert(false);
    } catch (const std::exception&) {
        assert(true);
    }

    repo.clearFile();
}

void testGetSize()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    assert(service.getSize() == 0);

    service.addTutorial("id", "title", "presenter", "duration", 0, "link");
    assert(service.getSize() == 1);

    repo.clearFile();
}

void testGetTutorial()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    service.addTutorial("id", "title", "presenter", "duration", 0, "link");
    assert(service.getTutorial(0).getId() == "id");

    try {
        service.getTutorial(1);
        //assert(false);
    } catch (const std::exception&) {
        assert(true);
    }

    repo.clearFile();
}

void testAssigmentOperator()
{
    FileRepo repo("testService.txt");
    Service service(repo);

    service.addTutorial("id", "title", "presenter", "duration", 0, "link");

    FileRepo repo1("testService1.txt");
    Service copyService(repo1);

    copyService = service;

    assert(service.getTutorial(0) == copyService.getTutorial(0));

    repo.clearFile();
    repo1.clearFile();
}

void testAccessLink()
{
    Service service;

    service.accessLink("xdg-open https://www.example.com");

    assert(system("xdg-open https://www.example.com") == 0);
}

void testFilterByPresenter() {
    Service service;
    service.addTutorial("1", "Title1", "Presenter1", "30:12", 4, "www.youtube.com");
    service.addTutorial("2", "Title2", "Presenter2", "60:00", 5, "www.youtube.com");
    service.addTutorial("3", "Title3", "Presenter1", "45:30", 4, "www.youtube.com");
    
    std::vector<Tutorial> filteredTutorials = service.filterByPresenter("Presenter1");

    assert(filteredTutorials.size() == 2);
    assert(filteredTutorials.at(0).getTitle() == "Title1");
    assert(filteredTutorials.at(1).getTitle() == "Title3");
    assert(filteredTutorials.at(0).getDuration() == "30:12");
    assert(filteredTutorials.at(1).getDuration() == "45:30");
}

void testFilterByPresenterEmpty() {
    Service service;
    service.addTutorial("1", "Title1", "Presenter1", "30:12", 4, "www.youtube.com");
    service.addTutorial("2", "Title2", "Presenter2", "60:00", 5, "www.youtube.com");
    service.addTutorial("3", "Title3", "Presenter1", "45:30", 4, "www.youtube.com");

    std::vector<Tutorial> filteredTutorials = service.filterByPresenter("");

    assert(filteredTutorials.size() == 3);
}

void testAddToWatchList() {
    Service service;
    Tutorial tutorial1("1", "title1", "presenter1", "10:10", 10, "link1");
    Tutorial  tutorial2("2", "title2", "presenter2", "20:20", 11, "link2");


    service.addToWatchList(tutorial1);

    try {
        service.addToWatchList(tutorial1);
        assert(false);
    }
    catch (std::exception&) {
        assert(true);
    }

    service.addToWatchList(tutorial2);

    std::vector<Tutorial> watchList = service.getWatchList();
    assert(watchList.size() == 2);
    assert(watchList.at(0) == tutorial1);
    assert(watchList.at(1) == tutorial2);
}

void testSearchWatchList() {
    Service service;
    Tutorial tutorial1("1", "title1", "presenter1", "10:10", 10, "link1");
    Tutorial  tutorial2("2", "title2", "presenter2", "20:20", 10, "link2");


    service.addToWatchList(tutorial1);
    service.addToWatchList(tutorial2);

    Tutorial foundTutorial = service.searchWatchList("title1");
    assert(foundTutorial == tutorial1);

    try {
        service.searchWatchList("title3");
        assert(false);
    }
    catch (std::exception&) {
        assert(true);
    }
}

void testDeleteWatchList() {
    Service service;
    Tutorial tutorial1("1", "title1", "presenter1", "10:10", 10, "link1");
    Tutorial  tutorial2("2", "title2", "presenter2", "20:20", 11, "link2");

    service.addToWatchList(tutorial1);
    service.addToWatchList(tutorial2);

    service.deleteWatchList(tutorial1);

    std::vector<Tutorial> watchList = service.getWatchList();
    assert(watchList.size() == 1);
    assert(watchList.at(0) == tutorial2);

    service.deleteWatchList(tutorial2);

    watchList = service.getWatchList();
    assert(watchList.size() == 0);

}

void testIncreaseLikesService() {
    Service service;
    Tutorial tutorial1("1", "title1", "presenter1", "10:10", 10, "link1");
    Tutorial tutorial2("2", "title2", "presenter2", "20:20", 10, "link2");

    service.addTutorial("1", "title1", "presenter1", "10:10", 10, "link1");
    service.addTutorial("2", "title2", "presenter2", "20:20", 10, "link2");

    service.addToWatchList(tutorial1);

    service.increaseLikes(tutorial1);

    std::vector<Tutorial> watchList = service.getWatchList();
}


void testSearchTutorial()
{
    Service service;
    Tutorial tutorial1("1", "title1", "presenter1", "10:10", 10, "link1");
    Tutorial tutorial2("2", "title2", "presenter2", "20:20", 10, "link2");

    service.addTutorial("1", "title1", "presenter1", "10:10", 10, "link1");
    service.addTutorial("2", "title2", "presenter2", "20:20", 10, "link2");


    assert(service.searchTutorial("1", "title1") == true);
    assert(service.searchTutorial("99", "title99") == false);
}


    void testAllService()
{
    testImplicitConstructorService();
    testAddTutorial();
    testAddTutorialNegLikes();
    testDeleteTutorial();
    testUpdateTutorial();
    testGetSize();
    testGetTutorial();
    testAssigmentOperator();
    testAccessLink();
    testFilterByPresenter();
    testFilterByPresenterEmpty();
    testAddToWatchList();
    testSearchWatchList();
    testDeleteWatchList();
    testIncreaseLikesService();
    testSearchTutorial();
}