//
// Created by Raul on 3/24/2023.
//

#include "../Headers/Tests.h"

void testAll(){

    testAllTutorial();
    testAllRepository();
    testAllService();
    testAllFileRepo();

}