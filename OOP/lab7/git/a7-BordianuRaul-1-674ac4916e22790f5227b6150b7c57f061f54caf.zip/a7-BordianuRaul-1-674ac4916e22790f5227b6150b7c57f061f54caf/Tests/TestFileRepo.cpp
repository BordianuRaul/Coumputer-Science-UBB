//
// Created by Raul on 5/2/2023.
//

#include "TestFileRepo.h"
#include "FileRepo.h"

void testCreateRepo()
{
    FileRepo repo("test.txt");
}

void testAddFileRepo()
{
    FileRepo repo("test.txt");

    Tutorial tutorial("1ABC", "Welcome to C++ tutorial!", "Mr. Kishore", "13:06", 2500,
                      "https://www.youtube.com/watch?v=wA8LriKDBAI");

    repo.addElem(tutorial);

    assert(repo.getSize() == 1);

    repo.clearFile();
}


void testLoadFromFileRepo()
{
    FileRepo repo("testRead.txt");

    assert(repo.getSize() == 2);
}

void testDeleteFileRepo()
{
    FileRepo repo("test.txt");

    Tutorial tutorial("1ABC", "Welcome to C++ tutorial!", "Mr. Kishore", "13:06", 2500,
                      "https://www.youtube.com/watch?v=wA8LriKDBAI");

    repo.addElem(tutorial);

    assert(repo.getSize() == 1);

    repo.deleteRepo(tutorial);

    assert(repo.getSize() == 0);
}
void testAllFileRepo()
{
    testCreateRepo();
    testAddFileRepo();
    testLoadFromFileRepo();
    testDeleteFileRepo();
}
