//
// Created by Raul on 3/25/2023.
//

#include "../Headers/Tutorial.h"

#include <vector>
#include <iostream>
#include "../Utils/Utils.h"

using namespace std;

Tutorial::Tutorial() {

    this->id = "";
    this->title = "";
    this->presenter = "";
    this->duration = "";
    this->nrLikes = -1;
    this->link = "";

}

Tutorial::Tutorial(const std::string &id, const std::string &title, const std::string &presenter,
                   const std::string &duration, int nrLikes, const std::string &link) {

    this->id = id;
    this->title = title;
    this->presenter = presenter;
    this->duration = duration;
    this->nrLikes = nrLikes;
    this->link = link;
}

Tutorial::~Tutorial() = default;

const std::string &Tutorial::getId() const {
    return id;
}

const std::string &Tutorial::getTitle() const {
    return title;
}

const std::string &Tutorial::getPresenter() const {
    return presenter;
}

const std::string &Tutorial::getDuration() const {
    return duration;
}

int Tutorial::getNrLikes() const {
    return nrLikes;
}

const std::string &Tutorial::getLink() const {
    return link;
}

bool Tutorial::operator==(const Tutorial &rhs) const {
    if(this->id == rhs.id || this->title == rhs.title)
        return true;
    return false;
}

bool Tutorial::operator!=(const Tutorial &rhs) const {
    return !(rhs == *this);
}

void Tutorial::increaseLikes()
{
    this->nrLikes++;
}

//std::istream& operator>>(std::istream& is, Tutorial& tutorial) {
//
//    std::string line;
//    getline(is, line);
//
//    vector<string> tokens = tokenize(line, ',');
//    if (tokens.size() != 6)
//        return is;
//
//    Tutorial readTutorial(tokens[0], tokens[1], tokens[2], tokens[3], std::stoi(tokens[4]), tokens[5]);
//
//    tutorial = readTutorial;
//
//    return is;
//}

