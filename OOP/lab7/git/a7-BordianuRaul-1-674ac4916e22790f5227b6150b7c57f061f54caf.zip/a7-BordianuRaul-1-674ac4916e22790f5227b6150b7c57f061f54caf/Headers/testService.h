//
// Created by Raul on 3/29/2023.
//

#ifndef A45_BORDIANURAUL_TESTSERVICE_H
#define A45_BORDIANURAUL_TESTSERVICE_H

#include "Tutorial.h"
#include "../Repository/Repository.h"
#include "Service.h"

void testAllService();

#endif //A45_BORDIANURAUL_TESTSERVICE_H
