//
// Created by Raul on 3/26/2023.
//

#ifndef A45_BORDIANURAUL_TESTTUTORIAL_H
#define A45_BORDIANURAUL_TESTTUTORIAL_H

#include "Tutorial.h"

void testConstructor();

void testAllTutorial();

#endif //A45_BORDIANURAUL_TESTTUTORIAL_H
