//
// Created by Raul on 5/1/2023.
//

#ifndef A7_BORDIANURAUL_1_FILEREPO_H
#define A7_BORDIANURAUL_1_FILEREPO_H


#include "Repository.h"
#include "Tutorial.h"

class FileRepo : public Repository<Tutorial> {
private:

    std::string filename;

public:

    FileRepo();

    FileRepo(std::string);

    virtual void addElem(Tutorial);

    std::string createStringTutorial(const Tutorial&);

    void writeToFile();

    void loadFromFile();

    void clearFile();

    virtual void deleteRepo(Tutorial);

    FileRepo& operator=(const FileRepo&);

};


#endif //A7_BORDIANURAUL_1_FILEREPO_H
