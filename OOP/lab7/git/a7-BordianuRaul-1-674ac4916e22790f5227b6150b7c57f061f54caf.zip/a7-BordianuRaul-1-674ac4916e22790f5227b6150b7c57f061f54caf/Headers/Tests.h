//
// Created by Raul on 3/24/2023.
//

#ifndef A45_BORDIANURAUL_TESTS_H
#define A45_BORDIANURAUL_TESTS_H

#include "TestTutorial.h"
#include "TestRepository.h"
#include "testService.h"
#include "TestFileRepo.h"

void testAll();

#endif //A45_BORDIANURAUL_TESTS_H
