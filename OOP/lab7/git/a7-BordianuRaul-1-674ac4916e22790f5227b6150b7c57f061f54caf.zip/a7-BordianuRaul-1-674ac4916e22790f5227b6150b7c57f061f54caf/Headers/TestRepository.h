//
// Created by Raul on 3/26/2023.
//

#ifndef A45_BORDIANURAUL_TESTREPOSITORY_H
#define A45_BORDIANURAUL_TESTREPOSITORY_H

#include "../Repository/Repository.h"
#include "Tutorial.h"


void testAllRepository();

#endif //A45_BORDIANURAUL_TESTREPOSITORY_H
