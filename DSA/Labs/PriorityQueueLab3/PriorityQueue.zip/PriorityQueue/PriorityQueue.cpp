
#include "PriorityQueue.h"
#include <exception>
using namespace std;


PriorityQueue::PriorityQueue(Relation r) {
	//TODO - Implementation
}


void PriorityQueue::push(TElem e, TPriority p) {
	//TODO - Implementation
}

//throws exception if the queue is empty
Element PriorityQueue::top() const {
	//TODO - Implementation
	return NULL_TELEM;
}

Element PriorityQueue::pop() {
	//TODO - Implementation
	return NULL_TELEM;
}

bool PriorityQueue::isEmpty() const {
	//TODO - Implementation
	return false;
}


PriorityQueue::~PriorityQueue() {
	//TODO - Implementation
};

