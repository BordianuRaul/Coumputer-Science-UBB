package textmenu.model.value;

import textmenu.model.adt.MyIDictionary;
import textmenu.model.type.Type;

public interface Value {

    Type getType();
}

