package textmenu.repository;

import textmenu.model.PrgState;

public interface IRepository {

    PrgState getCrtPrg();
}

