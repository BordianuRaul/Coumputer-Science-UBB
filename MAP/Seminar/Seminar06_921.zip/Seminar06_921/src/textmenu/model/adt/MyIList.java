package textmenu.model.adt;

public interface MyIList<T> {
}

