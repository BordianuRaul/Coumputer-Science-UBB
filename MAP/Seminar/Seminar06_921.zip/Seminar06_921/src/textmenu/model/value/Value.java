package textmenu.model.value;

public interface Value {
}

