package textmenu.model.type;

import textmenu.model.value.Value;

public interface Type {
    Value defaultValue();
}