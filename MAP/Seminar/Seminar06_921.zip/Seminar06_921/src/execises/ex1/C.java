package execises.ex1;

public class C extends A{
    @Override
    public String toString() {
        return "C";
    }
}