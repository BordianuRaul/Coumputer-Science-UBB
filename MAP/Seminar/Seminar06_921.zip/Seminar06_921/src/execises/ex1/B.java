package execises.ex1;

public class B extends A{
    @Override
    public String toString() {
        return "B";
    }
}