package execises.ex2;

public class B extends A{

    @Override
    public String toString() {
        return "B";
    }
}


