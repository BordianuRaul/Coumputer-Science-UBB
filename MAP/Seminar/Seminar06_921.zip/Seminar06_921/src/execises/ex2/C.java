package execises.ex2;

public class C extends B{
    @Override
    public String toString() {
        return "C";
    }
}

