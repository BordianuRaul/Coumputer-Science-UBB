package execises.ex2;

public class A {

    @Override
    public String toString() {
        return "A";
    }
}

