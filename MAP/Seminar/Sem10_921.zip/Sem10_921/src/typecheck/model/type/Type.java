package typecheck.model.type;

import typecheck.model.value.Value;

public interface Type {
    Value defaultValue();
}
