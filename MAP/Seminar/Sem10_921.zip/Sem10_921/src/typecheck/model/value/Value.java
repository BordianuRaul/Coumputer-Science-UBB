package typecheck.model.value;

import typecheck.model.type.Type;

public interface Value {

    Type getType();
}
