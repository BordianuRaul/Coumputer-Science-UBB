package typecheck.model.adt;

public interface MyIList<T> {
}
