package typecheck.repository;

import typecheck.model.PrgState;

public interface IRepository {

    PrgState getCrtPrg();
}
