package p3_p4.v0;

public interface Predicate1<T> {
    boolean check(T e);
}