package p3_p4.v0;

public interface Function1 <T> {
    T app(T e);
}

